﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Listagem
{
    internal class Anuncio
    {
        public string Id { get; private set; } = Guid.NewGuid().ToString(); // ID único para cada anúncio
        //O nome do produto (Ex: Arroz, Feijao)
        public string Nome { get; set; }

        // O valor dele (Ex: R$ 50.00)
        public double Preco { get; set; }

        // o fornecedor do produto (Ex: Camil, Pilao)
        public string Fornecedor { get; set; }

        // Um construtor - nascimento do anuncio 
        public Anuncio(string nome, double preco,string fornecedor, string? id = null)
        {
            Id = id ?? Guid.NewGuid().ToString();
            Nome = nome;
            Preco = preco;
            Fornecedor = fornecedor;

        }


    }
}
