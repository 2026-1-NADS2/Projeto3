﻿using Listagem;


var repo = new AnuncioDB("meus_anuncios.db");


int pagina = 1;
    int itensPorPagina = 4;
    while (true)
    {
        Console.Clear();
        Console.WriteLine("________________________________________");
        Console.WriteLine($"   NOSSOS ANÚNCIOS (Página {pagina})  ");
        Console.WriteLine("________________________________________");


        var lista = repo.ObterPagina(pagina, itensPorPagina);

        if (lista.Count == 0)
        {
            Console.WriteLine("\nFim dos anúncios ou página vazia.");
            if (pagina > 1) Console.WriteLine("Aperte [A] para voltar.");
        }
        else
        {
            foreach (var item in lista)
            {
                Console.WriteLine($"- {item.Nome} ({item.Fornecedor}) | R$ {item.Preco:F2}");
            }
        }

        Console.WriteLine("\n[N] Próxima | [A] Anterior | [S] Sair");
        char tecla = Console.ReadKey(true).KeyChar;

        if (tecla == 'n' || tecla == 'N')
        {
            if (lista.Count > 0) pagina++;
        }
        else if ((tecla == 'a' || tecla == 'A') && pagina > 1)
        {
            pagina--;
        }
        else if (tecla == 's' || tecla == 'S')
        {
            break;
        }
    }