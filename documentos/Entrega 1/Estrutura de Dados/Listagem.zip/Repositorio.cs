﻿using Microsoft.Data.Sqlite;

namespace Listagem
{
    internal class AnuncioDB
    {
        private readonly string _connectionString;

        public AnuncioDB(string CaminhoBanco)
        {
            _connectionString = $"Data Source={CaminhoBanco}";
            CriarTabelaSeNaoExistir();
        }

        private void CriarTabelaSeNaoExistir()
        {
            using var conexao = new SqliteConnection(_connectionString);
            conexao.Open();

            using var comando = conexao.CreateCommand();
            comando.CommandText = @"
                CREATE TABLE IF NOT EXISTS Anuncios (
                    Id TEXT PRIMARY KEY,
                    Nome TEXT NOT NULL, 
                    Preco REAL NOT NULL,
                    Fornecedor TEXT NOT NULL,
                    UNIQUE(Nome, Fornecedor)
                ); ";
            comando.ExecuteNonQuery();
        }

        // Inserir - usando Parâmetros (Segurança)
        public void Inserir(Anuncio item)
        {

            using var conexao = new SqliteConnection(_connectionString);
            conexao.Open(); 
            // comandos em sql 
            using var comando = conexao.CreateCommand();

            comando.CommandText = "INSERT INTO Anuncios (Id, Nome, Preco, Fornecedor) VALUES (@id, @nome, @preco, @fornecedor)";
            comando.Parameters.AddWithValue("@id", item.Id); // Salvar o ID que foi gerado no objeto
            comando.Parameters.AddWithValue("@nome", item.Nome);
            comando.Parameters.AddWithValue("@preco", item.Preco);
            comando.Parameters.AddWithValue("@fornecedor", item.Fornecedor);

            comando.ExecuteNonQuery();
        }

        // Paginação 
        public List<Anuncio> ObterPagina(int pagina, int tamanho)
        {
            var lista = new List<Anuncio>();
            int pular = (pagina - 1) * tamanho;

            using var conexao = new SqliteConnection(_connectionString);
            conexao.Open();
            using var comando = conexao.CreateCommand();

           
            comando.CommandText = "SELECT Id, Nome, Preco, Fornecedor FROM Anuncios LIMIT @tamanho OFFSET @pular";
            comando.Parameters.AddWithValue("@tamanho", tamanho);
            comando.Parameters.AddWithValue("@pular", pular);

            using var reader = comando.ExecuteReader();
            while (reader.Read())
            {
                lista.Add(new Anuncio(reader.GetString(1), reader.GetDouble(2), reader.GetString(3), reader.GetString(0)));
            }
            return lista;
        }
    }
}