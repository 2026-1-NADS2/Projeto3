# Hermes

Sistema web de cadastro e gerenciamento de empresas com autenticação JWT.

---

## O que você vai precisar instalar

Antes de qualquer coisa, instale os programas abaixo na ordem:

### 1. Node.js
- Acesse: https://nodejs.org
- Baixe a versão **LTS** (botão verde à esquerda)
- Execute o instalador e clique em Next até o fim
- Para confirmar que instalou, abra o terminal e digite:
  ```
  node -v
  ```
  Deve aparecer algo como `v20.11.0`

### 2. Git
- Acesse: https://git-scm.com/download/win
- Baixe e instale (pode deixar todas as opções padrão)
- Para confirmar, no terminal:
  ```
  git --version
  ```

---

## Clonando o projeto

Abra o terminal em uma pasta onde queira salvar o projeto e rode:

```bash
git clone https://github.com/seu-usuario/seu-repositorio.git
cd seu-repositorio
```

---

## Configurando o banco de dados

1. Abra o **MySQL Workbench**
2. Clique em **Local instance MySQL** para conectar
3. Vá em **File → Open SQL Script**
4. Selecione o arquivo `banco.sql` que está na raiz do projeto
5. Clique no ícone do raio ⚡ (ou `Ctrl + Shift + Enter`) para executar
6. No painel esquerdo deve aparecer o banco **sistema_usuarios** com as tabelas `users` e `empresas`

---

## Configurando o backend

Entre na pasta `backend/`:

```bash
cd backend
```

Crie um arquivo chamado `.env` dentro dessa pasta.

> **No Windows:** abra o Bloco de Notas, cole o conteúdo abaixo, e salve com o nome `.env` — na hora de salvar, mude o tipo de arquivo para **"Todos os arquivos"**.

Conteúdo do `.env`:

```
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=sua_senha_do_mysql
DB_NAME=sistema_usuarios
JWT_SECRET=coloque_qualquer_texto_longo_aqui
PORT=3001
```

> Substitua `sua_senha_do_mysql` pela senha que você usa para entrar no Workbench.

Agora instale as dependências e inicie o servidor:

```bash
npm install
node server.js
```

Se aparecer a mensagem abaixo, está funcionando:

```
Servidor rodando na porta 3001
```

> Deixe esse terminal aberto enquanto usa o sistema.

---

## Abrindo o frontend

Vá até a pasta `frontend/` e dê dois cliques no arquivo `index.html`.

Ele abrirá direto no navegador e já estará conectado ao backend.

---

## Estrutura do projeto

```
hermes/
├── banco.sql                  ← script do banco de dados
├── .gitignore
├── README.md
├── backend/
│   ├── server.js              ← entrypoint da API
│   ├── db.js                  ← conexão com MySQL
│   ├── authController.js      ← login, cadastro, perfil
│   ├── authMiddleware.js      ← validação do JWT
│   ├── empresasController.js  ← CRUD de empresas
│   └── package.json
└── frontend/
    └── index.html             ← interface completa
```

---

## Endpoints da API

| Método | Rota           | Auth | Descrição          |
|--------|----------------|------|--------------------|
| POST   | /auth/register | Não  | Cadastrar usuário  |
| POST   | /auth/login    | Não  | Login              |
| GET    | /users/me      | Sim  | Ver meu perfil     |
| PUT    | /users/me      | Sim  | Editar meu perfil  |
| DELETE | /users/me      | Sim  | Excluir minha conta|
| GET    | /empresas      | Sim  | Listar empresas    |
| GET    | /empresas/:id  | Sim  | Ver uma empresa    |
| POST   | /empresas      | Sim  | Cadastrar empresa  |
| PUT    | /empresas/:id  | Sim  | Editar empresa     |
| DELETE | /empresas/:id  | Sim  | Remover empresa    |


## Banco de dados

O arquivo `banco.sql` contém todo o código necessário para criar o banco.

1. Abra o **MySQL Workbench** e conecte na instância local (Local instance MySQL)
2. Vá em **File → Open SQL Script** e selecione o arquivo `banco.sql`
3. Clique no ícone do raio ⚡ ou pressione `Ctrl + Shift + Enter` para executar
4. O banco `sistema_usuarios` e as tabelas serão criados automaticamente

## Rodando o servidor

Dentro da pasta `backend/`, execute no terminal:

```bash
npm install
node server.js
```

O `npm install` só precisa ser rodado uma vez para instalar as dependências.
Deixe o terminal com `node server.js` aberto enquanto usar o sistema.