const bcrypt = require('bcryptjs')
const jwt = require('jsonwebtoken')
const pool = require('./db')
require('dotenv').config()

const sanitizeUser = (user) => {
  const {password, ...safe} = user
  return safe
}

const createToken = (payload) => jwt.sign(payload, process.env.JWT_SECRET, {expiresIn: '8h'})

const validarCNPJ = (cnpj) => {
  cnpj = cnpj.replace(/[^\d]/g, '')
  if(cnpj.length !== 14) return false
  if(/^(\d)\1+$/.test(cnpj)) return false
  return true
}

async function register(req, res) {
  const {nome, email, password, cnpj} = req.body
  if(!nome || !email || !password || !cnpj)
    return res.status(400).json({error: 'Todos os campos são obrigatórios'})
  if(!validarCNPJ(cnpj))
    return res.status(400).json({error: 'CNPJ inválido'})
  try {
    const [existente] = await pool.query(
      'SELECT id FROM users WHERE email=? OR cnpj=?',
      [email, cnpj.replace(/[^\d]/g, '')]
    )
    if(existente.length)
      return res.status(409).json({error: 'Email ou CNPJ já cadastrado'})
    const hash = await bcrypt.hash(password, 10)
    const cnpjLimpo = cnpj.replace(/[^\d]/g, '')
    const [result] = await pool.query(
      'INSERT INTO users (nome, email, password, cnpj) VALUES (?,?,?,?)',
      [nome, email, hash, cnpjLimpo]
    )
    const token = createToken({id: result.insertId})
    res.status(201).json({token, user: {id: result.insertId, nome, email, cnpj: cnpjLimpo}})
  } catch {
    res.status(500).json({error: 'Erro ao registrar o usuário'})
  }
}

async function login(req, res) {
  const {email, password} = req.body
  if(!email || !password)
    return res.status(400).json({error: 'Email e Password Obrigatórios'})
  try {
    const [rows] = await pool.query(
      'SELECT * FROM users WHERE email=?',
      [email]
    )
    if(!rows.length)
      return res.status(401).json({error: 'Credenciais Inválidas'})
    const user = rows[0]
    const match = await bcrypt.compare(password, user.password)
    if(!match)
      return res.status(401).json({error: 'Credenciais Inválidas'})
    const token = createToken({id: user.id})
    res.json({token, user: sanitizeUser(user)})
  } catch {
    res.status(500).json({error: 'Erro no Login'})
  }
}

async function getMe(req, res) {
  try {
    const [rows] = await pool.query(
      'SELECT id, nome, email, cnpj, created_at FROM users WHERE id=?',
      [req.userId]
    )
    if(!rows.length)
      return res.status(404).json({error: 'Usuário não encontrado'})
    res.json({user: rows[0]})
  } catch {
    res.status(500).json({error: 'Erro ao buscar usuário'})
  }
}

async function updateMe(req, res) {
  const {nome, email, cnpj} = req.body
  if(!nome && !email && !cnpj)
    return res.status(400).json({error: 'Nenhum campo para atualizar'})
  try {
    const fields = []
    const values = []
    if(nome){ fields.push('nome=?'); values.push(nome) }
    if(email){ fields.push('email=?'); values.push(email) }
    if(cnpj){
      if(!validarCNPJ(cnpj)) return res.status(400).json({error: 'CNPJ inválido'})
      fields.push('cnpj=?'); values.push(cnpj.replace(/[^\d]/g, ''))
    }
    values.push(req.userId)
    await pool.query(`UPDATE users SET ${fields.join(',')} WHERE id=?`, values)
    const [rows] = await pool.query(
      'SELECT id, nome, email, cnpj, created_at FROM users WHERE id=?',
      [req.userId]
    )
    res.json({user: rows[0]})
  } catch {
    res.status(500).json({error: 'Erro ao atualizar usuário'})
  }
}

async function deleteMe(req, res) {
  try {
    const [rows] = await pool.query('SELECT id FROM users WHERE id=?', [req.userId])
    if(!rows.length)
      return res.status(404).json({error: 'Usuário não encontrado'})
    await pool.query('DELETE FROM users WHERE id=?', [req.userId])
    res.json({message: 'Conta deletada com sucesso'})
  } catch {
    res.status(500).json({error: 'Erro ao deletar conta'})
  }
}

module.exports = {register, login, getMe, updateMe, deleteMe}
