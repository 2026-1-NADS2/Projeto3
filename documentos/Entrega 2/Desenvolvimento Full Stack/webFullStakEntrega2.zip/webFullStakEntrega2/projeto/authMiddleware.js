const jwt = require('jsonwebtoken')
require('dotenv').config()

module.exports = (req, res, next) => {
  const auth = req.headers['authorization']
  if(!auth) return res.status(401).json({error: 'Token não fornecido'})
  const token = auth.split(' ')[1]
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET)
    req.userId = decoded.id
    next()
  } catch {
    return res.status(401).json({error: 'Token inválido'})
  }
}
