const express = require('express')
const cors = require('cors')
require('dotenv').config()

const {register, login, getMe, updateMe, deleteMe} = require('./authController')
const auth = require('./authMiddleware')

const app = express()
app.use(cors())
app.use(express.json())

app.post('/auth/register', register)
app.post('/auth/login', login)
app.get('/users/me', auth, getMe)
app.put('/users/me', auth, updateMe)
app.delete('/users/me', auth, deleteMe)

const PORT = process.env.PORT || 3001
app.listen(PORT, () => console.log(`Servidor rodando na porta ${PORT}`))
